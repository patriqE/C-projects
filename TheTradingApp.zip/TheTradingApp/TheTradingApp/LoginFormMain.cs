﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheTradingApp
{
    public partial class LoginFormMain : Form
    {
        private const string ConnectionString = "Data Source=TradingApp.db;Version=3;";
        public LoginFormMain()
        {
            InitializeComponent();
            cmbRole.Items.AddRange(new object[] { "Admin", "Trader" });
            cmbRole.SelectedIndex = 0; // Default to Admin
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            string role = cmbRole.SelectedItem.ToString();
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT UserId, Role FROM Users WHERE Username = @username AND Password = @password";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", password); // Plain text for now; hashing later
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            int userId = reader.GetInt32(0);
                            string dbRole = reader.GetString(1);
                            if (dbRole == role)
                            {
                                MessageBox.Show($"Welcome, {username} ({role})!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                // TODO: Open AdminForm or TraderForm based on role
                                // For now, close login form
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Selected role does not match account.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Invalid username or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                }
            }
        }
    }
}
