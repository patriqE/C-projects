﻿using System;
using System.Data.SQLite;

public class DatabaseHelper
{
    private const string ConnectionString = "Data Source=TradingApp.db;Version=3;";

    public static void InitializeDatabase()
    {
        using (var connection = new SQLiteConnection(ConnectionString))
        {
            connection.Open();
            string createUsersTable = @"
                CREATE TABLE IF NOT EXISTS Users (
                    UserId INTEGER PRIMARY KEY AUTOINCREMENT,
                    Username TEXT NOT NULL UNIQUE,
                    Password TEXT NOT NULL,
                    Role TEXT NOT NULL CHECK(Role IN ('Admin', 'Trader')),
                    Balance REAL DEFAULT 0.0
                )";
            string createStocksTable = @"
                CREATE TABLE IF NOT EXISTS Stocks (
                    StockId INTEGER PRIMARY KEY AUTOINCREMENT,
                    StockName TEXT NOT NULL UNIQUE
                )";
            string createTransactionsTable = @"
                CREATE TABLE IF NOT EXISTS Transactions (
                    TransactionId INTEGER PRIMARY KEY AUTOINCREMENT,
                    UserId INTEGER,
                    StockId INTEGER,
                    Type TEXT NOT NULL CHECK(Type IN ('Buy', 'Sell')),
                    Price REAL NOT NULL,
                    Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(UserId) REFERENCES Users(UserId),
                    FOREIGN KEY(StockId) REFERENCES Stocks(StockId)
                )";
            string createLogsTable = @"
                CREATE TABLE IF NOT EXISTS Logs (
                    LogId INTEGER PRIMARY KEY AUTOINCREMENT,
                    Activity TEXT NOT NULL,
                    UserId INTEGER,
                    Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(UserId) REFERENCES Users(UserId)
                )";

            using (var command = new SQLiteCommand(connection))
            {
                command.CommandText = createUsersTable;
                command.ExecuteNonQuery();
                command.CommandText = createStocksTable;
                command.ExecuteNonQuery();
                command.CommandText = createTransactionsTable;
                command.ExecuteNonQuery();
                command.CommandText = createLogsTable;
                command.ExecuteNonQuery();
            }
            // Insert default admin user
            string insertAdminUser = @"
                INSERT OR IGNORE INTO Users (Username, Password, Role) 
                VALUES ('admin', 'admin123', 'Admin')";
            using (var command = new SQLiteCommand(insertAdminUser, connection))
            {
                command.ExecuteNonQuery();
            }
        }
    }
}